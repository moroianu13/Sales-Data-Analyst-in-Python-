*As a data analyst, the process of working with a newly received dataset like Sales.csv typically involves several steps. Here’s a general outline of what we can do:*

Data Loading: Load the data to understand its structure and format.

Data Cleaning: Check for and handle missing values, duplicates, or incorrect entries.

Exploratory Data Analysis (EDA): Examine the data to find patterns, trends, and anomalies.

Visualization: Create charts and graphs to visualize findings and trends in the data.

Statistical Analysis: Apply statistical methods to test hypotheses or find significant differences and correlations.

Reporting: Summarize the findings and potentially prepare a report or presentation.


```python
import pandas as pd

# Load the CSV file
file_path = r"C:\Users\moroi\OneDrive\Desktop\Sales.csv" 
sales_data = pd.read_csv(file_path)

# Display the first few rows of the dataframe
sales_data.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Day</th>
      <th>Month</th>
      <th>Year</th>
      <th>Customer_Age</th>
      <th>Age_Group</th>
      <th>Customer_Gender</th>
      <th>Country</th>
      <th>State</th>
      <th>Product_Category</th>
      <th>Sub_Category</th>
      <th>Product</th>
      <th>Order_Quantity</th>
      <th>Unit_Cost</th>
      <th>Unit_Price</th>
      <th>Profit</th>
      <th>Cost</th>
      <th>Revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>26</td>
      <td>November</td>
      <td>2013</td>
      <td>19</td>
      <td>Youth (&lt;25)</td>
      <td>M</td>
      <td>Canada</td>
      <td>British Columbia</td>
      <td>Accessories</td>
      <td>Bike Racks</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>8</td>
      <td>45</td>
      <td>120</td>
      <td>590</td>
      <td>360</td>
      <td>950</td>
    </tr>
    <tr>
      <th>1</th>
      <td>26</td>
      <td>November</td>
      <td>2015</td>
      <td>19</td>
      <td>Youth (&lt;25)</td>
      <td>M</td>
      <td>Canada</td>
      <td>British Columbia</td>
      <td>Accessories</td>
      <td>Bike Racks</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>8</td>
      <td>45</td>
      <td>120</td>
      <td>590</td>
      <td>360</td>
      <td>950</td>
    </tr>
    <tr>
      <th>2</th>
      <td>23</td>
      <td>March</td>
      <td>2014</td>
      <td>49</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>Australia</td>
      <td>New South Wales</td>
      <td>Accessories</td>
      <td>Bike Racks</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>23</td>
      <td>45</td>
      <td>120</td>
      <td>1366</td>
      <td>1035</td>
      <td>2401</td>
    </tr>
    <tr>
      <th>3</th>
      <td>23</td>
      <td>March</td>
      <td>2016</td>
      <td>49</td>
      <td>Adults (35-64)</td>
      <td>M</td>
      <td>Australia</td>
      <td>New South Wales</td>
      <td>Accessories</td>
      <td>Bike Racks</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>20</td>
      <td>45</td>
      <td>120</td>
      <td>1188</td>
      <td>900</td>
      <td>2088</td>
    </tr>
    <tr>
      <th>4</th>
      <td>15</td>
      <td>May</td>
      <td>2014</td>
      <td>47</td>
      <td>Adults (35-64)</td>
      <td>F</td>
      <td>Australia</td>
      <td>New South Wales</td>
      <td>Accessories</td>
      <td>Bike Racks</td>
      <td>Hitch Rack - 4-Bike</td>
      <td>4</td>
      <td>45</td>
      <td>120</td>
      <td>238</td>
      <td>180</td>
      <td>418</td>
    </tr>
  </tbody>
</table>
</div>






```python
# Check for missing values in the dataset
missing_values = sales_data.isnull().sum()

# Check for duplicate rows in the dataset
duplicate_rows = sales_data.duplicated().sum()

missing_values, duplicate_rows

```




    (Day                 0
     Month               0
     Year                0
     Customer_Age        0
     Age_Group           0
     Customer_Gender     0
     Country             0
     State               0
     Product_Category    0
     Sub_Category        0
     Product             0
     Order_Quantity      0
     Unit_Cost           0
     Unit_Price          0
     Profit              0
     Cost                0
     Revenue             0
     dtype: int64,
     0)



Let’s start EDA with some basic statistics and distribution insights for key numerical columns like Customer_Age, Order_Quantity, Unit_Cost, Unit_Price, Profit, Cost, and Revenue. I'll also include visualizations for better understanding. 


```python
import matplotlib.pyplot as plt
import seaborn as sns

# Setting up the aesthetic style for the plots
sns.set(style="whitegrid")

# Creating a figure to plot multiple subplots
fig, axes = plt.subplots(nrows=3, ncols=2, figsize=(14, 16))

# Histograms for key numerical columns
sns.histplot(sales_data['Customer_Age'], bins=30, kde=True, ax=axes[0, 0])
axes[0, 0].set_title('Distribution of Customer Age')

sns.histplot(sales_data['Order_Quantity'], bins=30, kde=True, ax=axes[0, 1])
axes[0, 1].set_title('Distribution of Order Quantity')

sns.histplot(sales_data['Unit_Cost'], bins=30, kde=True, ax=axes[1, 0])
axes[1, 0].set_title('Distribution of Unit Cost')

sns.histplot(sales_data['Unit_Price'], bins=30, kde=True, ax=axes[1, 1])
axes[1, 1].set_title('Distribution of Unit Price')

sns.histplot(sales_data['Profit'], bins=30, kde=True, ax=axes[2, 0])
axes[2, 0].set_title('Distribution of Profit')

sns.histplot(sales_data['Revenue'], bins=30, kde=True, ax=axes[2, 1])
axes[2, 1].set_title('Distribution of Revenue')

plt.tight_layout()
plt.show()

```


    
![png](output_11_0.png)
    


Average profit by product category. Sales Revenue by Country. Distribution of Customer Age by Age Group


```python
# Setting up a larger figure size for better visibility
plt.figure(figsize=(10, 6))

# Bar plot for average profit by product category
sns.barplot(x='Product_Category', y='Profit', data=sales_data, estimator=sum, errorbar=None)
plt.title('Total Profit by Product Category')
plt.ylabel('Sum of Profit')
plt.xlabel('Product Category')
plt.xticks(rotation=45)
plt.show()

# Next, we'll plot sales revenue by country
plt.figure(figsize=(10, 6))
sns.barplot(x='Country', y='Revenue', data=sales_data, estimator=sum, errorbar=None)
plt.title('Total Sales Revenue by Country')
plt.ylabel('Sum of Revenue')
plt.xlabel('Country')
plt.xticks(rotation=45)
plt.show()

# Lastly, boxplot for the distribution of customer age by age group
plt.figure(figsize=(10, 6))
sns.boxplot(x='Age_Group', y='Customer_Age', data=sales_data)
plt.title('Distribution of Customer Age by Age Group')
plt.ylabel('Customer Age')
plt.xlabel('Age Group')
plt.xticks(rotation=45)
plt.show()

```


    
![png](output_13_0.png)
    



    
![png](output_13_1.png)
    



    
![png](output_13_2.png)
    


: Apply statistical methods to test hypotheses or find significant differences and correlations.


```python

import pandas as pd
from scipy.stats import kruskal

# Load your data
data = pd.read_csv(r"C:\Users\moroi\OneDrive\Desktop\Sales.csv" )

# Group data by 'Product_Category' and list profits
category_groups = [group['Profit'].values for name, group in data.groupby('Product_Category')]

# Kruskal-Wallis test
stat, p_value = kruskal(*category_groups)
print('Kruskal-Wallis Test Statistic:', stat)
print('P-value:', p_value)



```

    Kruskal-Wallis Test Statistic: 42069.8020717006
    P-value: 0.0
    

Setting up Dunn's Test


```python
import pandas as pd
import scikit_posthocs as sp
from scipy.stats import kruskal



# Group data by 'Product_Category' and list profits
category_groups = data.groupby('Product_Category')['Profit']

# Performing Kruskal-Wallis test first
stat, p_value = kruskal(*[group.values for name, group in category_groups])

# If Kruskal-Wallis test is significant, proceed with Dunn's test
if p_value < 0.05:
    # Convert groups to a form suitable for post-hoc analysis
    data['group_codes'] = data['Product_Category'].astype('category').cat.codes
    # Dunn's test for multiple comparisons
    result = sp.posthoc_dunn(data, val_col='Profit', group_col='group_codes', p_adjust='bonferroni')
    print(result)

```

                  0    1             2
    0  1.000000e+00  0.0  2.063910e-17
    1  0.000000e+00  1.0  0.000000e+00
    2  2.063910e-17  0.0  1.000000e+00
    

What products each country should focus on based on profitability and popularity:


```python
import pandas as pd



# Group data by 'Country' and 'Product', then calculate total profit, total revenue, and total quantity sold
product_performance = data.groupby(['Country', 'Product']).agg(
    Total_Profit=('Profit', 'sum'),
    Total_Revenue=('Revenue', 'sum'),
    Total_Quantity=('Order_Quantity', 'sum')
).reset_index()

# Determine top products by profit and quantity sold for each country
top_products_by_profit = product_performance.sort_values(['Country', 'Total_Profit'], ascending=False).groupby('Country').head(3)
top_products_by_demand = product_performance.sort_values(['Country', 'Total_Quantity'], ascending=False).groupby('Country').head(3)

print("Top Products by Profit in Each Country:")
print(top_products_by_profit)

print("\nTop Products by Demand in Each Country:")
print(top_products_by_demand)

```

    Top Products by Profit in Each Country:
                Country                  Product  Total_Profit  Total_Revenue  \
    652   United States  Mountain-200 Silver, 42        514692        1243908   
    674   United States         Road-150 Red, 52        487265        1366520   
    650   United States   Mountain-200 Black, 46        463854        1158714   
    527  United Kingdom   Mountain-200 Black, 38        264398         612454   
    588  United Kingdom    Sport-100 Helmet, Red        244543         398866   
    531  United Kingdom  Mountain-200 Silver, 42        220080         509994   
    407         Germany  Mountain-200 Silver, 46        155581         413845   
    406         Germany  Mountain-200 Silver, 42        146987         359675   
    405         Germany  Mountain-200 Silver, 38        140396         363212   
    341          France    Sport-100 Helmet, Red        128758         228845   
    277          France  Mountain-200 Silver, 46        117575         327731   
    340          France   Sport-100 Helmet, Blue        116908         205308   
    155          Canada   Mountain-200 Black, 38        170340         379424   
    212          Canada   Sport-100 Helmet, Blue        169659         271514   
    136          Canada    Fender Set - Mountain        163968         259208   
    61        Australia         Road-150 Red, 62        383223        1331950   
    32        Australia   Mountain-200 Black, 38        277633         778433   
    35        Australia  Mountain-200 Silver, 38        254311         734125   
    
         Total_Quantity  
    652             576  
    674             405  
    650             555  
    527             278  
    588           11871  
    531             229  
    407             204  
    406             168  
    405             176  
    341            7699  
    277             166  
    340            6800  
    155             167  
    212            7835  
    136           11905  
    61              437  
    32              400  
    35              379  
    
    Top Products by Demand in Each Country:
                Country                Product  Total_Profit  Total_Revenue  \
    741   United States  Water Bottle - 30 oz.        154661         275563   
    667   United States    Patch Kit/8 Patches         43599          99193   
    639   United States     Mountain Tire Tube        107154         194260   
    612  United Kingdom  Water Bottle - 30 oz.         54834          94006   
    590  United Kingdom      Touring Tire Tube         41221          70659   
    544  United Kingdom    Patch Kit/8 Patches         12375          25780   
    496         Germany  Water Bottle - 30 oz.         30972          55916   
    422         Germany    Patch Kit/8 Patches          9440          21239   
    370         Germany           AWC Logo Cap          9102          67937   
    292          France    Patch Kit/8 Patches         11955          28742   
    366          France  Water Bottle - 30 oz.         33280          62344   
    343          France      Touring Tire Tube         18787          35271   
    153          Canada     Mountain Tire Tube         79655         133533   
    174          Canada    Patch Kit/8 Patches         25218          50743   
    237          Canada  Water Bottle - 30 oz.         66939         112213   
    126       Australia  Water Bottle - 30 oz.         72053         136799   
    52        Australia    Patch Kit/8 Patches         21811          54011   
    23        Australia     Mountain Tire Tube         35864          67698   
    
         Total_Quantity  
    741           60451  
    667           55594  
    639           43553  
    612           19586  
    590           14719  
    544           13405  
    496           12472  
    422           11799  
    370            8405  
    292           16787  
    366           14532  
    343            8242  
    153           26939  
    174           25525  
    237           22637  
    126           32373  
    52            32200  
    23            15917  
    


```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns



# Calculate total revenue by country for normalization later
total_revenue_by_country = data.groupby('Country')['Revenue'].sum().reset_index()
total_revenue_by_country.rename(columns={'Revenue': 'Revenue_total'}, inplace=True)

# Compute metrics for top demanding and top profitable products
product_performance = data.groupby(['Country', 'Product']).agg(
    Total_Revenue=('Revenue', 'sum'),
    Total_Profit=('Profit', 'sum'),
    Total_Quantity=('Order_Quantity', 'sum')
).reset_index()

# Determine top products by profit and demand
top_profit = product_performance.sort_values(['Country', 'Total_Profit'], ascending=False).groupby('Country').head(1)
top_demand = product_performance.sort_values(['Country', 'Total_Quantity'], ascending=False).groupby('Country').head(1)

# Merge to get total revenue for normalization
top_profit = pd.merge(top_profit, total_revenue_by_country, on='Country')
top_demand = pd.merge(top_demand, total_revenue_by_country, on='Country')

# Calculate revenue percentages
top_profit['Revenue_Percent'] = top_profit['Total_Revenue'] / top_profit['Revenue_total'] * 100
top_demand['Revenue_Percent'] = top_demand['Total_Revenue'] / top_demand['Revenue_total'] * 100

# Visualization
plt.figure(figsize=(12, 6))
sns.barplot(data=top_profit, x='Country', y='Revenue_Percent', color='blue', label='Most Profitable')
sns.barplot(data=top_demand, x='Country', y='Revenue_Percent', color='green', alpha=0.6, label='Most Demanding')
plt.title('Revenue Percentage: Most Profitable vs. Most Demanding Products by Country')
plt.ylabel('Percentage of Total Revenue')
plt.xlabel('Country')
plt.legend()
plt.show()

```


    
![png](output_20_0.png)
    



```python

```
